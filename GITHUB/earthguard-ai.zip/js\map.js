/**
 * EarthGuard AI - Map Engine & NASA GIBS Tile Integration
 * NASA Space Apps Challenge Project
 */

import { APP_CONFIG, NASA_LAYERS, REGIONAL_PRESETS } from './config.js';

export class EarthGuardMap {
  constructor(mapContainerId, options = {}) {
    this.containerId = mapContainerId;
    this.options = options;
    this.map = null;

    // Layer management
    this.primaryGibsLayer = null;
    this.compareGibsLayer = null;
    this.referenceLabelsLayer = null;
    this.bangladeshBoundaryLayer = null;

    // State
    this.currentDateA = options.initialDate || "2024-05-15";
    this.currentLayerIdA = options.initialLayerId || "modis_terra_truecolor";
    this.currentDateB = options.initialDateB || "2024-07-15";
    this.currentLayerIdB = options.initialLayerIdB || "modis_terra_bands721";
    this.isCompareMode = false;
    this.splitPosition = 50; // Percentage 0 - 100
    this.layerOpacity = 1.0;
    this.showLabels = true;

    // Callbacks
    this.onLoadingChange = options.onLoadingChange || (() => {});
    this.onError = options.onError || (() => {});
    this.onCoordinatesMove = options.onCoordinatesMove || (() => {});

    this.initMap();
  }

  initMap() {
    // Initialize Leaflet Map centered on Bangladesh
    this.map = L.map(this.containerId, {
      center: APP_CONFIG.defaultCenter,
      zoom: APP_CONFIG.defaultZoom,
      minZoom: APP_CONFIG.minZoom,
      maxZoom: 11, // Allows zooming past GIBS level 9 with client-side scaling
      zoomControl: false,
      attributionControl: false
    });

    // Custom attribution control in space style
    L.control.attribution({
      position: 'bottomright',
      prefix: false
    }).addTo(this.map).addAttribution(
      '<span class="map-attr">Imagery: <strong>NASA EOSDIS GIBS</strong> | Map: <strong>EarthGuard AI</strong></span>'
    );

    // Add Base Dark World Layer (fallback when tiles load or outside tile bounds)
    this.baseDarkLayer = L.tileLayer(
      'https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png',
      {
        subdomains: 'abcd',
        maxZoom: 19,
        zIndex: 1
      }
    ).addTo(this.map);

    // Reference Labels & Boundaries overlay (can be toggled)
    this.referenceLabelsLayer = L.tileLayer(
      'https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png',
      {
        subdomains: 'abcd',
        maxZoom: 19,
        zIndex: 20
      }
    );
    if (this.showLabels) {
      this.referenceLabelsLayer.addTo(this.map);
    }

    // Add subtle Bangladesh highlight polygon / outline for geographical orientation
    this.addBangladeshOutline();

    // Create Primary NASA GIBS layer
    this.updatePrimaryLayer();

    // Setup Split-Slider overlay elements
    this.setupSplitSliderUI();

    // Bind map events
    this.bindMapEvents();
  }

  /**
   * Build NASA GIBS WMTS Tile URL for EPSG:3857 (Web Mercator)
   */
  buildGibsUrl(layerId, dateStr) {
    const layer = NASA_LAYERS[layerId] || NASA_LAYERS.modis_terra_truecolor;
    return `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${layer.gibsLayer}/default/${dateStr}/${layer.tileMatrixSet}/{z}/{y}/{x}.${layer.format}`;
  }

  /**
   * Create or refresh Primary Satellite Layer (Layer A)
   */
  updatePrimaryLayer() {
    this.onLoadingChange(true, "Fetching NASA satellite imagery...");

    if (this.primaryGibsLayer) {
      this.map.removeLayer(this.primaryGibsLayer);
      this.primaryGibsLayer = null;
    }

    const layerConfig = NASA_LAYERS[this.currentLayerIdA] || NASA_LAYERS.modis_terra_truecolor;
    const tileUrl = this.buildGibsUrl(this.currentLayerIdA, this.currentDateA);

    this.primaryGibsLayer = L.tileLayer(tileUrl, {
      maxNativeZoom: layerConfig.maxZoom || 9,
      maxZoom: 11,
      opacity: this.layerOpacity,
      zIndex: 5,
      className: 'gibs-tile-layer-primary',
      tileSize: 256,
      updateWhenIdle: false,
      crossOrigin: true
    });

    this.hookTileEvents(this.primaryGibsLayer, "Primary Layer");
    this.primaryGibsLayer.addTo(this.map);

    // If in compare mode, also update clip path
    if (this.isCompareMode) {
      this.applySplitClipping();
    }
  }

  /**
   * Create or refresh Comparison Layer (Layer B)
   */
  updateCompareLayer() {
    if (!this.isCompareMode) {
      if (this.compareGibsLayer) {
        this.map.removeLayer(this.compareGibsLayer);
        this.compareGibsLayer = null;
      }
      return;
    }

    this.onLoadingChange(true, "Fetching comparison satellite imagery...");

    if (this.compareGibsLayer) {
      this.map.removeLayer(this.compareGibsLayer);
      this.compareGibsLayer = null;
    }

    const layerConfig = NASA_LAYERS[this.currentLayerIdB] || NASA_LAYERS.modis_terra_bands721;
    const tileUrl = this.buildGibsUrl(this.currentLayerIdB, this.currentDateB);

    this.compareGibsLayer = L.tileLayer(tileUrl, {
      maxNativeZoom: layerConfig.maxZoom || 9,
      maxZoom: 11,
      opacity: this.layerOpacity,
      zIndex: 6,
      className: 'gibs-tile-layer-compare',
      tileSize: 256,
      updateWhenIdle: false,
      crossOrigin: true
    });

    this.hookTileEvents(this.compareGibsLayer, "Comparison Layer");
    this.compareGibsLayer.addTo(this.map);

    this.applySplitClipping();
  }

  /**
   * Attach loading & error listeners to tile layers
   */
  hookTileEvents(tileLayer, label) {
    let failedTilesCount = 0;

    tileLayer.on('loading', () => {
      failedTilesCount = 0;
      this.onLoadingChange(true, `Connecting to NASA GIBS (${label})...`);
    });

    tileLayer.on('load', () => {
      this.onLoadingChange(false, "Tiles loaded successfully");
    });

    tileLayer.on('tileerror', (error) => {
      failedTilesCount++;
      // If several tiles fail, notify user (e.g. today's imagery might still be processing)
      if (failedTilesCount === 4) {
        this.onError({
          title: "NASA Imagery Ingestion Pending",
          message: `Some satellite tiles for ${this.currentDateA} are not yet published by NASA GIBS or fell outside the coverage path. Satellites require 3-5 hours post-orbit to calibrate and publish tiles. Consider choosing yesterday or an earlier date.`
        });
      }
    });
  }

  /**
   * Set up interactive split-slider handle and curtain UI
   */
  setupSplitSliderUI() {
    const mapContainer = document.getElementById(this.containerId);
    if (!mapContainer) return;

    // Create split slider overlay DOM elements
    const splitOverlay = document.createElement('div');
    splitOverlay.id = 'mapSplitOverlay';
    splitOverlay.className = 'map-split-overlay hidden';
    splitOverlay.innerHTML = `
      <div class="split-divider-line" id="splitDivider">
        <div class="split-handle" id="splitHandle" title="Drag to compare before & after">
          <div class="handle-arrow-left">◀</div>
          <div class="handle-center-grip"></div>
          <div class="handle-arrow-right">▶</div>
        </div>
      </div>
      <div class="split-tag tag-left" id="splitTagLeft">
        <span class="tag-title">Date A</span>
        <span class="tag-val" id="splitTagLeftVal">--</span>
      </div>
      <div class="split-tag tag-right" id="splitTagRight">
        <span class="tag-title">Date B</span>
        <span class="tag-val" id="splitTagRightVal">--</span>
      </div>
    `;

    mapContainer.appendChild(splitOverlay);
    this.splitOverlay = splitOverlay;
    this.splitDivider = document.getElementById('splitDivider');
    this.splitHandle = document.getElementById('splitHandle');
    this.splitTagLeftVal = document.getElementById('splitTagLeftVal');
    this.splitTagRightVal = document.getElementById('splitTagRightVal');

    this.initSliderDrag();
  }

  initSliderDrag() {
    let isDragging = false;
    const overlay = this.splitOverlay;

    const onMove = (clientX) => {
      if (!isDragging) return;
      const rect = overlay.getBoundingClientRect();
      const x = clientX - rect.left;
      let percent = (x / rect.width) * 100;
      percent = Math.max(5, Math.min(95, percent)); // Keep within view bounds

      this.splitPosition = percent;
      this.applySplitClipping();
    };

    // Mouse drag
    this.splitHandle.addEventListener('mousedown', (e) => {
      isDragging = true;
      e.preventDefault();
    });

    window.addEventListener('mousemove', (e) => {
      if (isDragging) onMove(e.clientX);
    });

    window.addEventListener('mouseup', () => {
      if (isDragging) isDragging = false;
    });

    // Touch drag (mobile-friendly)
    this.splitHandle.addEventListener('touchstart', (e) => {
      isDragging = true;
    }, { passive: true });

    window.addEventListener('touchmove', (e) => {
      if (isDragging && e.touches.length > 0) {
        onMove(e.touches[0].clientX);
      }
    }, { passive: true });

    window.addEventListener('touchend', () => {
      if (isDragging) isDragging = false;
    });
  }

  /**
   * Applies CSS polygon clip-path to compare layer for smooth 60fps curtain reveal
   */
  applySplitClipping() {
    if (!this.isCompareMode) return;

    if (this.splitDivider) {
      this.splitDivider.style.left = `${this.splitPosition}%`;
    }

    if (this.compareGibsLayer) {
      const container = this.compareGibsLayer.getContainer();
      if (container) {
        // Compare layer (Date B) is revealed on the right side of the curtain
        container.style.clipPath = `polygon(${this.splitPosition}% 0, 100% 0, 100% 100%, ${this.splitPosition}% 100%)`;
      }
    }

    // Update tags
    if (this.splitTagLeftVal) {
      this.splitTagLeftVal.textContent = `${this.currentDateA} (${NASA_LAYERS[this.currentLayerIdA].badge})`;
    }
    if (this.splitTagRightVal) {
      this.splitTagRightVal.textContent = `${this.currentDateB} (${NASA_LAYERS[this.currentLayerIdB].badge})`;
    }
  }

  /**
   * Toggle between Single View and Split Comparison Mode
   */
  setCompareMode(enabled, dateB = null, layerIdB = null) {
    this.isCompareMode = enabled;

    if (dateB) this.currentDateB = dateB;
    if (layerIdB) this.currentLayerIdB = layerIdB;

    if (this.splitOverlay) {
      if (enabled) {
        this.splitOverlay.classList.remove('hidden');
      } else {
        this.splitOverlay.classList.add('hidden');
      }
    }

    if (enabled) {
      this.updateCompareLayer();
    } else {
      if (this.compareGibsLayer) {
        this.map.removeLayer(this.compareGibsLayer);
        this.compareGibsLayer = null;
      }
    }
  }

  /**
   * Set active date for Layer A
   */
  setDateA(dateStr) {
    if (this.currentDateA === dateStr) return;
    this.currentDateA = dateStr;
    this.updatePrimaryLayer();
    if (this.isCompareMode) {
      this.applySplitClipping();
    }
  }

  /**
   * Set active layer for Layer A
   */
  setLayerA(layerId) {
    if (this.currentLayerIdA === layerId) return;
    this.currentLayerIdA = layerId;
    this.updatePrimaryLayer();
    if (this.isCompareMode) {
      this.applySplitClipping();
    }
  }

  /**
   * Set active date for Layer B
   */
  setDateB(dateStr) {
    this.currentDateB = dateStr;
    if (this.isCompareMode) {
      this.updateCompareLayer();
    }
  }

  /**
   * Set active layer for Layer B
   */
  setLayerB(layerId) {
    this.currentLayerIdB = layerId;
    if (this.isCompareMode) {
      this.updateCompareLayer();
    }
  }

  /**
   * Set satellite layer opacity (0.1 to 1.0)
   */
  setOpacity(val) {
    this.layerOpacity = parseFloat(val);
    if (this.primaryGibsLayer) {
      this.primaryGibsLayer.setOpacity(this.layerOpacity);
    }
    if (this.compareGibsLayer) {
      this.compareGibsLayer.setOpacity(this.layerOpacity);
    }
  }

  /**
   * Toggle reference labels overlay
   */
  toggleLabels(visible) {
    this.showLabels = visible;
    if (visible) {
      if (!this.map.hasLayer(this.referenceLabelsLayer)) {
        this.referenceLabelsLayer.addTo(this.map);
      }
    } else {
      if (this.map.hasLayer(this.referenceLabelsLayer)) {
        this.map.removeLayer(this.referenceLabelsLayer);
      }
    }
  }

  /**
   * Fly to predefined region
   */
  flyToRegion(regionPresetId) {
    const preset = REGIONAL_PRESETS.find(p => p.id === regionPresetId);
    if (preset) {
      this.map.flyTo(preset.center, preset.zoom, {
        duration: 1.4,
        easeLinearity: 0.25
      });
    }
  }

  /**
   * Reset view to default Bangladesh center
   */
  resetToBangladesh() {
    this.map.flyTo(APP_CONFIG.defaultCenter, APP_CONFIG.defaultZoom, {
      duration: 1.2
    });
  }

  /**
   * Bangladesh regional bounds highlight (delicate cyan geo outline)
   */
  addBangladeshOutline() {
    // Stylized bounding polygon roughly encompassing Bangladesh coordinates
    const bdCoordinates = [
      [26.634, 88.028], [26.444, 88.948], [25.750, 89.850], [25.180, 89.700],
      [25.180, 92.480], [24.890, 92.530], [24.250, 91.950], [23.950, 91.300],
      [23.400, 91.450], [22.800, 92.350], [22.400, 92.650], [21.150, 92.350],
      [20.550, 92.350], [21.500, 91.800], [21.700, 90.500], [21.650, 89.150],
      [22.250, 89.050], [23.000, 88.650], [23.850, 88.650], [24.700, 88.010],
      [25.200, 88.200], [26.050, 88.250], [26.634, 88.028]
    ];

    L.polygon(bdCoordinates, {
      color: '#38bdf8',
      weight: 1.5,
      dashArray: '4, 6',
      fillColor: '#0ea5e9',
      fillOpacity: 0.03,
      interactive: false
    }).addTo(this.map);
  }

  bindMapEvents() {
    // Coordinate readout on mouse move
    this.map.on('mousemove', (e) => {
      this.onCoordinatesMove({
        lat: e.latlng.lat.toFixed(4),
        lng: e.latlng.lng.toFixed(4),
        zoom: this.map.getZoom()
      });
    });

    // Reapply clip path on map zoom / pan in compare mode
    this.map.on('zoomend moveend', () => {
      if (this.isCompareMode) {
        this.applySplitClipping();
      }
    });
  }
}
