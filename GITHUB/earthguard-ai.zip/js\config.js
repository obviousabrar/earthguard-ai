/**
 * EarthGuard AI - Configuration & Scientific Metadata
 * NASA Space Apps Challenge Project
 * Target: Students, Local Communities & Earth Science Enthusiasts
 */

export const APP_CONFIG = {
  name: "EarthGuard AI",
  subtitle: "NASA Earth Observation & Environmental Intelligence",
  version: "1.0.0",
  targetRegion: "Bangladesh & Bay of Bengal",
  defaultCenter: [23.6850, 90.3563], // Geographic center of Bangladesh
  defaultZoom: 7,
  minZoom: 4,
  maxZoom: 9, // NASA GIBS EPSG:3857 standard max zoom level is 9 for MODIS/VIIRS Corrected Reflectance
};

/**
 * Supported NASA GIBS (Global Imagery Browse Services) Layers
 * Endpoints use public WMTS EPSG:3857 (Web Mercator / GoogleMapsCompatible)
 */
export const NASA_LAYERS = {
  modis_terra_truecolor: {
    id: "modis_terra_truecolor",
    gibsLayer: "MODIS_Terra_CorrectedReflectance_TrueColor",
    tileMatrixSet: "GoogleMapsCompatible_Level9",
    format: "jpg",
    name: "MODIS Terra (True Color)",
    satellite: "Terra (EOS AM-1)",
    sensor: "MODIS (Moderate Resolution Imaging Spectroradiometer)",
    orbit: "Sun-synchronous, ~10:30 AM local crossing time (Morning pass)",
    resolution: "250 meters per pixel (at nadir)",
    description: "Natural color composite (Bands 1, 4, 3) approximating human vision. Excellent for viewing smoke, haze, dust storms, flood sediment plumes, and general atmospheric conditions.",
    badge: "Natural Color",
    badgeColor: "#38bdf8",
    maxZoom: 9,
    startDate: "2000-02-24",
    bestFor: "Daytime environmental observation, cloud patterns, sediment flow in the Bay of Bengal"
  },
  viirs_snpp_truecolor: {
    id: "viirs_snpp_truecolor",
    gibsLayer: "VIIRS_SNPP_CorrectedReflectance_TrueColor",
    tileMatrixSet: "GoogleMapsCompatible_Level9",
    format: "jpg",
    name: "VIIRS Suomi-NPP (True Color)",
    satellite: "Suomi-NPP",
    sensor: "VIIRS (Visible Infrared Imaging Radiometer Suite)",
    orbit: "Sun-synchronous, ~1:30 PM local crossing time",
    resolution: "375 meters per pixel (imagery bands)",
    description: "High-clarity true color view combining VIIRS red, green, and blue spectral channels. Sharper imagery across the edges of the satellite scan swath.",
    badge: "High-Clarity True Color",
    badgeColor: "#06b6d4",
    maxZoom: 9,
    startDate: "2012-01-20",
    bestFor: "Sharper coastline visualization, delta sediment detection, afternoon weather tracking"
  },
  modis_aqua_truecolor: {
    id: "modis_aqua_truecolor",
    gibsLayer: "MODIS_Aqua_CorrectedReflectance_TrueColor",
    tileMatrixSet: "GoogleMapsCompatible_Level9",
    format: "jpg",
    name: "MODIS Aqua (True Color)",
    satellite: "Aqua (EOS PM-1)",
    sensor: "MODIS (Moderate Resolution Imaging Spectroradiometer)",
    orbit: "Sun-synchronous, ~1:30 PM local crossing time (Afternoon pass)",
    resolution: "250 meters per pixel",
    description: "Afternoon natural color pass. Comparing Terra (morning) and Aqua (afternoon) reveals cloud development and rapid river runoff dynamics on the same day.",
    badge: "Afternoon Pass",
    badgeColor: "#818cf8",
    maxZoom: 9,
    startDate: "2002-07-04",
    bestFor: "Afternoon cloud changes, storm tracking, daily comparison against Terra"
  },
  modis_terra_bands721: {
    id: "modis_terra_bands721",
    gibsLayer: "MODIS_Terra_CorrectedReflectance_Bands721",
    tileMatrixSet: "GoogleMapsCompatible_Level9",
    format: "jpg",
    name: "MODIS Terra (False Color Bands 7-2-1)",
    satellite: "Terra (EOS AM-1)",
    sensor: "MODIS Shortwave Infrared / Near Infrared / Red",
    orbit: "Sun-synchronous morning pass",
    resolution: "250 meters per pixel",
    description: "False-color composite mapping Shortwave IR (Band 7), Near-IR (Band 2), and Red (Band 1). Standing water absorbs infrared and appears deep blue or black; healthy vegetation strongly reflects Near-IR and appears bright vibrant green; clouds appear white or cyan. Crucial for flood mapping in Bangladesh.",
    badge: "Water & Flood Detection",
    badgeColor: "#10b981",
    maxZoom: 9,
    startDate: "2000-02-24",
    bestFor: "Flooding extent, distinguishing river boundaries from agricultural land, haor inundation"
  },
  viirs_nightlights: {
    id: "viirs_nightlights",
    gibsLayer: "VIIRS_SNPP_DayNightBand_AtSensor_Radiance",
    tileMatrixSet: "GoogleMapsCompatible_Level8",
    format: "jpg",
    name: "VIIRS Nighttime Day/Night Band",
    satellite: "Suomi-NPP",
    sensor: "VIIRS Day/Night Band (DNB)",
    orbit: "Nocturnal pass (~1:30 AM local time)",
    resolution: "750 meters per pixel",
    description: "Ultra-sensitive low-light sensor capturing nighttime surface emissions: city lights, fishing vessel fleets in the Bay of Bengal, gas flares, and widespread power outage footprints following severe cyclones.",
    badge: "Night Lights & Energy",
    badgeColor: "#f59e0b",
    maxZoom: 8,
    startDate: "2012-01-20",
    bestFor: "Urban footprints, coastal fishing boat illumination, power infrastructure resilience"
  }
};

/**
 * Bangladesh Regional Bookmarks for Quick Exploration
 */
export const REGIONAL_PRESETS = [
  {
    id: "national",
    name: "🇧🇩 All Bangladesh & Bay of Bengal",
    center: [23.6850, 90.3563],
    zoom: 7,
    description: "Overview of the Bengal Delta, Himalayan foothills to the north, and the Bay of Bengal to the south."
  },
  {
    id: "sylhet",
    name: "💧 Sylhet Haor Basin (Flash Flood Zone)",
    center: [24.8949, 91.8687],
    zoom: 8,
    description: "Vast bowl-shaped wetland depression vulnerable to rapid pre-monsoon flash floods from Meghalaya hills."
  },
  {
    id: "padma_jamuna",
    name: "🌊 Padma-Jamuna Confluence (Brahmaputra)",
    center: [23.7500, 89.8000],
    zoom: 9,
    description: "Massive braided river system with shifting sand islands (chars) and high sediment transport rates."
  },
  {
    id: "sundarbans",
    name: "🌿 Sundarbans Mangrove Forest",
    center: [21.9497, 89.1833],
    zoom: 8,
    description: "UNESCO World Heritage mangrove ecosystem acting as a natural biosheild against Bay of Bengal cyclones."
  },
  {
    id: "chittagong_coast",
    name: "🏖️ Chittagong & Cox's Bazar Coastal Belt",
    center: [21.9162, 91.9158],
    zoom: 8,
    description: "Dynamic marine shoreline, submarine canyons, sediment dispersal plumes, and hilly terrain."
  },
  {
    id: "dhaka_metro",
    name: "🏙️ Greater Dhaka Urban Center",
    center: [23.8103, 90.4125],
    zoom: 9,
    description: "High-density metropolis surrounded by the Buriganga, Turag, and Balu rivers."
  }
];

/**
 * Curated Earth Science Case Studies & Comparative Events
 */
export const COMPARATIVE_PRESETS = [
  {
    id: "monsoon_flood_2024",
    title: "Monsoon Flood Inundation vs Dry Season (2024)",
    region: "Sylhet & Eastern Floodplains",
    dateA: "2024-03-05", // Dry season
    dateB: "2024-07-12", // Peak monsoon inundation
    layerA: "modis_terra_bands721",
    layerB: "modis_terra_bands721",
    center: [24.7000, 91.5000],
    zoom: 8,
    summary: "Compare pre-monsoon agricultural landscape with severe monsoon inundation. Bands 7-2-1 highlights water bodies in dark black/deep blue against bright green vegetation."
  },
  {
    id: "cyclone_remal_2024",
    title: "Cyclone Remal Impact & Cloud Vortices (May 2024)",
    region: "Coastal Bangladesh & Sundarbans",
    dateA: "2024-05-20", // Before cyclone
    dateB: "2024-05-26", // Landfall day
    layerA: "modis_terra_truecolor",
    layerB: "modis_terra_truecolor",
    center: [22.2000, 89.7000],
    zoom: 7,
    summary: "Observe the massive spiral cloud bands and coastal surge sediment plumes during Severe Cyclonic Storm Remal landfall."
  },
  {
    id: "river_sediment_seasonal",
    title: "Padma River Sediment Plume Dynamics",
    region: "Padma & Meghna Estuary to Bay of Bengal",
    dateA: "2024-01-15", // Winter clear calm water
    dateB: "2024-08-20", // Heavy silt discharge
    layerA: "viirs_snpp_truecolor",
    layerB: "viirs_snpp_truecolor",
    center: [22.8000, 90.5000],
    zoom: 8,
    summary: "Visualizes the immense volume of suspended sediment (silts and sand) transported from Himalayan glacier melt down into the Bay of Bengal."
  },
  {
    id: "nightlights_urban_contrast",
    title: "Nocturnal Energy Footprints (Dhaka vs Coastal Waters)",
    region: "Central & Southern Bangladesh",
    dateA: "2024-02-15",
    dateB: "2024-02-15",
    layerA: "viirs_snpp_truecolor",
    layerB: "viirs_nightlights",
    center: [23.2000, 90.3000],
    zoom: 7,
    summary: "Day vs Night split view. See how urban centers shine at night, and discover the bright clusters of night-fishing vessels off the Bay of Bengal continental shelf."
  }
];

/**
 * Scientific Limitations & Data Integrity Disclosure
 */
export const SCIENTIFIC_LIMITATIONS = {
  dataSource: "NASA Earth Science Data and Information System (ESDIS) - Global Imagery Browse Services (GIBS)",
  dataLatency: "MODIS and VIIRS imagery are typically processed and published to GIBS within 3 to 5 hours of satellite overpass.",
  limitations: [
    {
      title: "Optical Cloud Obstruction",
      description: "Passive optical sensors (MODIS & VIIRS) cannot penetrate clouds, dense rainstorms, or heavy fog. During monsoon cyclones, surface details may be hidden beneath cloud cover."
    },
    {
      title: "Spatial Resolution Scale",
      description: "Pixel footprint ranges from 250 meters to 750 meters. This macro-scale imagery is designed for regional river basin, weather, and delta monitoring — it cannot resolve individual buildings, streets, or vehicles."
    },
    {
      title: "Temporal Revisit Interval",
      description: "Satellites pass overhead 1 to 2 times daily per sensor. Imagery represents a discrete instantaneous snapshot in time, not a live streaming camera."
    },
    {
      title: "Projection & Geometric Distortions",
      description: "Display uses Web Mercator (EPSG:3857) projection for smooth interactive web map navigation, which introduces standard polar area enlargement."
    }
  ],
  ethicalDisclaimer: "⚠️ SCIENTIFIC ACCURACY POLICY: EarthGuard AI provides educational interpretations of public Earth observations. It strictly does NOT predict future natural disasters, estimate human casualties, or fabricate sensor measurements. For real-time life safety warnings, always consult the Bangladesh Meteorological Department (BMD) and Flood Forecasting and Warning Centre (FFWC)."
};
