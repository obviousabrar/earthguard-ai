/**
 * EarthGuard AI - Compare Dates & Dual Observation Controller
 * NASA Space Apps Challenge Project
 */

import { COMPARATIVE_PRESETS, NASA_LAYERS } from './config.js';

export class EarthGuardCompareController {
  constructor(mapInstance, aiAssistantInstance, options = {}) {
    this.map = mapInstance;
    this.ai = aiAssistantInstance;
    this.options = options;

    this.isActive = false;
    this.dateA = "2024-03-05"; // Default comparative: Dry Season
    this.dateB = "2024-07-12"; // Default comparative: Monsoon Flood
    this.layerA = "modis_terra_bands721";
    this.layerB = "modis_terra_bands721";

    this.initUI();
  }

  initUI() {
    this.modalEl = document.getElementById('compareModal');
    this.panelEl = document.getElementById('compareControlsBar');
    this.toggleBtn = document.getElementById('compareToggleBtn');

    this.bindEvents();
    this.renderCaseStudyCards();
  }

  bindEvents() {
    if (this.toggleBtn) {
      this.toggleBtn.addEventListener('click', () => {
        this.toggleCompareMode(!this.isActive);
      });
    }

    const closeBtn = document.getElementById('closeComparePanel');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        this.toggleCompareMode(false);
      });
    }

    // Date B picker in top/compare toolbar
    const datePickerB = document.getElementById('compareDatePickerB');
    if (datePickerB) {
      datePickerB.value = this.dateB;
      datePickerB.addEventListener('change', (e) => {
        this.dateB = e.target.value;
        this.map.setDateB(this.dateB);
        this.updateAssistantContext();
      });
    }

    // Layer B selector
    const layerSelectB = document.getElementById('compareLayerSelectB');
    if (layerSelectB) {
      layerSelectB.value = this.layerB;
      layerSelectB.addEventListener('change', (e) => {
        this.layerB = e.target.value;
        this.map.setLayerB(this.layerB);
        this.updateAssistantContext();
      });
    }

    // Swap Dates button
    const swapBtn = document.getElementById('swapDatesBtn');
    if (swapBtn) {
      swapBtn.addEventListener('click', () => {
        this.swapDates();
      });
    }

    // Animate Swipe button
    const animBtn = document.getElementById('animateSwipeBtn');
    if (animBtn) {
      animBtn.addEventListener('click', () => {
        this.animateCurtain();
      });
    }
  }

  toggleCompareMode(enable) {
    this.isActive = enable;

    if (this.panelEl) {
      if (enable) {
        this.panelEl.classList.remove('hidden');
      } else {
        this.panelEl.classList.add('hidden');
      }
    }

    if (this.toggleBtn) {
      if (enable) {
        this.toggleBtn.classList.add('active');
        this.toggleBtn.innerHTML = `
          <span class="btn-icon">✕</span>
          <span>Exit Compare</span>
        `;
      } else {
        this.toggleBtn.classList.remove('active');
        this.toggleBtn.innerHTML = `
          <span class="btn-icon">⚖️</span>
          <span>Compare Dates</span>
        `;
      }
    }

    // Pass to map
    this.map.setCompareMode(enable, this.dateB, this.layerB);
    this.updateAssistantContext();
  }

  loadCaseStudy(presetId) {
    const preset = COMPARATIVE_PRESETS.find(p => p.id === presetId);
    if (!preset) return;

    this.dateA = preset.dateA;
    this.dateB = preset.dateB;
    this.layerA = preset.layerA;
    this.layerB = preset.layerB;

    // Update form elements
    const datePickerA = document.getElementById('observationDatePicker');
    const datePickerB = document.getElementById('compareDatePickerB');
    const layerSelectA = document.getElementById('layerSelect');
    const layerSelectB = document.getElementById('compareLayerSelectB');

    if (datePickerA) datePickerA.value = this.dateA;
    if (datePickerB) datePickerB.value = this.dateB;
    if (layerSelectA) layerSelectA.value = this.layerA;
    if (layerSelectB) layerSelectB.value = this.layerB;

    // Apply to map
    this.map.setDateA(this.dateA);
    this.map.setLayerA(this.layerA);
    this.map.setDateB(this.dateB);
    this.map.setLayerB(this.layerB);

    if (preset.center && preset.zoom) {
      this.map.map.flyTo(preset.center, preset.zoom, { duration: 1.5 });
    }

    if (!this.isActive) {
      this.toggleCompareMode(true);
    } else {
      this.map.setCompareMode(true, this.dateB, this.layerB);
      this.updateAssistantContext();
    }
  }

  swapDates() {
    const tempDate = this.dateA;
    this.dateA = this.dateB;
    this.dateB = tempDate;

    const tempLayer = this.layerA;
    this.layerA = this.layerB;
    this.layerB = tempLayer;

    // Update DOM inputs
    const datePickerA = document.getElementById('observationDatePicker');
    const datePickerB = document.getElementById('compareDatePickerB');
    const layerSelectA = document.getElementById('layerSelect');
    const layerSelectB = document.getElementById('compareLayerSelectB');

    if (datePickerA) datePickerA.value = this.dateA;
    if (datePickerB) datePickerB.value = this.dateB;
    if (layerSelectA) layerSelectA.value = this.layerA;
    if (layerSelectB) layerSelectB.value = this.layerB;

    this.map.setDateA(this.dateA);
    this.map.setLayerA(this.layerA);
    this.map.setDateB(this.dateB);
    this.map.setLayerB(this.layerB);

    this.updateAssistantContext();
  }

  animateCurtain() {
    let start = null;
    const duration = 2400; // ms
    const initialPos = this.map.splitPosition;

    const step = (timestamp) => {
      if (!start) start = timestamp;
      const progress = (timestamp - start) / duration;
      if (progress < 1) {
        // Sine wave animation between 15% and 85%
        const pos = 50 + 35 * Math.sin(progress * Math.PI * 2);
        this.map.splitPosition = pos;
        this.map.applySplitClipping();
        requestAnimationFrame(step);
      } else {
        this.map.splitPosition = 50;
        this.map.applySplitClipping();
      }
    };

    requestAnimationFrame(step);
  }

  updateAssistantContext() {
    this.ai.updateContext({
      isCompareMode: this.isActive,
      date: this.dateA,
      layerId: this.layerA,
      dateB: this.dateB,
      layerIdB: this.layerB
    });
  }

  renderCaseStudyCards() {
    const container = document.getElementById('caseStudiesList');
    if (!container) return;

    container.innerHTML = COMPARATIVE_PRESETS.map(preset => `
      <div class="case-study-card" data-preset-id="${preset.id}">
        <div class="case-header">
          <span class="case-badge">CASE STUDY</span>
          <span class="case-region">${preset.region}</span>
        </div>
        <h4 class="case-title">${preset.title}</h4>
        <div class="case-dates-row">
          <span class="case-date-pill">A: ${preset.dateA}</span>
          <span class="date-arrow">➔</span>
          <span class="case-date-pill">B: ${preset.dateB}</span>
        </div>
        <p class="case-desc">${preset.summary}</p>
        <button class="case-load-btn" data-preset-id="${preset.id}">
          <span>Load Case Study</span>
          <span>➜</span>
        </button>
      </div>
    `).join('');

    // Attach listeners
    container.querySelectorAll('.case-load-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.getAttribute('data-preset-id');
        this.loadCaseStudy(id);

        // Close modal if open
        const modal = document.getElementById('caseStudiesModal');
        if (modal) modal.classList.add('hidden');
      });
    });
  }
}
