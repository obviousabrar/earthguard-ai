/**
 * EarthGuard AI - Application Orchestrator
 * NASA Space Apps Challenge Project
 */

import { APP_CONFIG, NASA_LAYERS, REGIONAL_PRESETS, SCIENTIFIC_LIMITATIONS } from './config.js';
import { EarthGuardMap } from './map.js';
import { EarthGuardAIAssistant } from './ai-assistant.js';
import { EarthGuardCompareController } from './compare.js';
import { EarthGuardTrendUI } from './trend-ui.js';

class EarthGuardApp {
  constructor() {
    this.map = null;
    this.assistant = null;
    this.compare = null;
    this.trendUI = null;

    // Default state: pick a reliable clear pre-monsoon date as initial anchor
    this.currentDate = "2024-05-15";
    this.currentLayerId = "modis_terra_truecolor";

    this.init();
  }

  init() {
    this.initDateLimits();
    this.initMapAndComponents();
    this.bindHeaderControls();
    this.bindModals();
    this.bindKeyboardShortcuts();
    this.renderRegionPresets();
    this.renderSourceInfo();
  }

  initDateLimits() {
    const today = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('observationDatePicker');
    const dateInputB = document.getElementById('compareDatePickerB');

    [dateInput, dateInputB].forEach(input => {
      if (input) {
        input.max = today;
        input.min = "2000-02-24";
      }
    });

    if (dateInput) dateInput.value = this.currentDate;
  }

  initMapAndComponents() {
    // Status & Loading Indicator Handler
    const statusTextEl = document.getElementById('hudStatusText');
    const loadingSpinnerEl = document.getElementById('hudSpinner');
    const statusPillEl = document.getElementById('hudStatusPill');

    const onLoadingChange = (isLoading, message) => {
      if (loadingSpinnerEl) {
        loadingSpinnerEl.style.display = isLoading ? 'inline-block' : 'none';
      }
      if (statusTextEl) {
        statusTextEl.textContent = message || (isLoading ? 'Receiving satellite telemetry...' : 'Observation active');
      }
      if (statusPillEl) {
        if (isLoading) {
          statusPillEl.classList.add('loading');
        } else {
          statusPillEl.classList.remove('loading');
        }
      }
    };

    // Error toast handler
    const onError = (err) => {
      this.showToast(err.title || "Observation Notice", err.message, "warning");
    };

    // Coordinate readout handler
    const coordEl = document.getElementById('hudCoordinates');
    const onCoordinatesMove = ({ lat, lng, zoom }) => {
      if (coordEl) {
        coordEl.textContent = `${lat}° N, ${lng}° E | Zoom: ${zoom}x`;
      }
    };

    // Instantiate Map
    this.map = new EarthGuardMap('earthguardMap', {
      initialDate: this.currentDate,
      initialLayerId: this.currentLayerId,
      onLoadingChange,
      onError,
      onCoordinatesMove
    });

    // Instantiate AI Assistant
    const aiContainer = document.getElementById('aiAssistantContainer');
    this.assistant = new EarthGuardAIAssistant(aiContainer, (action, payload) => {
      this.handleAssistantAction(action, payload);
    });

    // Instantiate Compare Controller
    this.compare = new EarthGuardCompareController(this.map, this.assistant);

    // Instantiate Decadal Trend Analyzer (Mann-Kendall & Theil-Sen)
    this.trendUI = new EarthGuardTrendUI(this.assistant);

    // Initial update of assistant context
    this.assistant.updateContext({
      date: this.currentDate,
      layerId: this.currentLayerId,
      region: "Bangladesh (National View)"
    });
  }

  bindHeaderControls() {
    // Primary Date Picker
    const datePicker = document.getElementById('observationDatePicker');
    if (datePicker) {
      datePicker.addEventListener('change', (e) => {
        const newDate = e.target.value;
        if (newDate) {
          this.currentDate = newDate;
          this.map.setDateA(newDate);
          this.assistant.updateContext({ date: newDate });
          this.showToast("Date Updated", `Switched to NASA observations for ${newDate}`, "info");
        }
      });
    }

    // Quick Date Shift Buttons (-1 Day, -7 Days, Latest)
    const prevDayBtn = document.getElementById('prevDayBtn');
    if (prevDayBtn) {
      prevDayBtn.addEventListener('click', () => this.shiftDate(-1));
    }

    const nextDayBtn = document.getElementById('nextDayBtn');
    if (nextDayBtn) {
      nextDayBtn.addEventListener('click', () => this.shiftDate(1));
    }

    const clearSeasonBtn = document.getElementById('quickDrySeasonBtn');
    if (clearSeasonBtn) {
      clearSeasonBtn.addEventListener('click', () => {
        this.setDate("2024-03-05");
        this.showToast("Dry Season Selected", "Observing clear skies & low river water stages", "info");
      });
    }

    const monsoonBtn = document.getElementById('quickMonsoonBtn');
    if (monsoonBtn) {
      monsoonBtn.addEventListener('click', () => {
        this.setDate("2024-07-12");
        this.showToast("Peak Monsoon Selected", "Observing widespread haor flooding & sediment runoff", "info");
      });
    }

    // Layer Select dropdown
    const layerSelect = document.getElementById('layerSelect');
    if (layerSelect) {
      layerSelect.value = this.currentLayerId;
      layerSelect.addEventListener('change', (e) => {
        this.currentLayerId = e.target.value;
        this.map.setLayerA(this.currentLayerId);
        this.assistant.updateContext({ layerId: this.currentLayerId });
        this.updateLayerBadge(this.currentLayerId);
      });
      this.updateLayerBadge(this.currentLayerId);
    }

    // Opacity Slider
    const opacitySlider = document.getElementById('opacitySlider');
    const opacityVal = document.getElementById('opacityVal');
    if (opacitySlider) {
      opacitySlider.addEventListener('input', (e) => {
        const val = e.target.value;
        this.map.setOpacity(val / 100);
        if (opacityVal) opacityVal.textContent = `${val}%`;
      });
    }

    // Toggle Boundaries & Labels
    const toggleLabelsCheckbox = document.getElementById('toggleLabelsCheckbox');
    if (toggleLabelsCheckbox) {
      toggleLabelsCheckbox.addEventListener('change', (e) => {
        this.map.toggleLabels(e.target.checked);
      });
    }

    // Reset View Button
    const resetViewBtn = document.getElementById('resetViewBtn');
    if (resetViewBtn) {
      resetViewBtn.addEventListener('click', () => {
        this.map.resetToBangladesh();
        this.assistant.updateContext({ region: "Bangladesh (National View)" });
      });
    }

    // Mobile Navigation Drawer Toggle
    const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
    const sidebarPanel = document.getElementById('sidebarPanel');
    if (mobileSidebarToggle && sidebarPanel) {
      mobileSidebarToggle.addEventListener('click', () => {
        sidebarPanel.classList.toggle('open');
      });
    }

    // Close Mobile Drawer button
    const closeSidebarBtn = document.getElementById('closeSidebarBtn');
    if (closeSidebarBtn && sidebarPanel) {
      closeSidebarBtn.addEventListener('click', () => {
        sidebarPanel.classList.remove('open');
      });
    }

    // Snapshot Button
    const snapshotBtn = document.getElementById('snapshotBtn');
    if (snapshotBtn) {
      snapshotBtn.addEventListener('click', () => this.captureSnapshot());
    }
  }

  shiftDate(daysOffset) {
    const d = new Date(this.currentDate);
    d.setDate(d.getDate() + daysOffset);
    const newDateStr = d.toISOString().split('T')[0];
    this.setDate(newDateStr);
  }

  setDate(dateStr) {
    this.currentDate = dateStr;
    const dateInput = document.getElementById('observationDatePicker');
    if (dateInput) dateInput.value = dateStr;
    this.map.setDateA(dateStr);
    this.assistant.updateContext({ date: dateStr });
  }

  updateLayerBadge(layerId) {
    const badgeEl = document.getElementById('activeLayerBadge');
    const layer = NASA_LAYERS[layerId];
    if (badgeEl && layer) {
      badgeEl.textContent = layer.badge;
      badgeEl.style.backgroundColor = `${layer.badgeColor}25`;
      badgeEl.style.borderColor = layer.badgeColor;
      badgeEl.style.color = layer.badgeColor;
    }
  }

  renderRegionPresets() {
    const container = document.getElementById('regionPresetsContainer');
    if (!container) return;

    container.innerHTML = REGIONAL_PRESETS.map(preset => `
      <button class="region-chip" data-region-id="${preset.id}" title="${preset.description}">
        ${preset.name}
      </button>
    `).join('');

    container.querySelectorAll('.region-chip').forEach(btn => {
      btn.addEventListener('click', (e) => {
        container.querySelectorAll('.region-chip').forEach(c => c.classList.remove('active'));
        e.currentTarget.classList.add('active');
        const id = e.currentTarget.getAttribute('data-region-id');
        const preset = REGIONAL_PRESETS.find(p => p.id === id);
        if (preset) {
          this.map.flyToRegion(id);
          this.assistant.updateContext({ region: preset.name });
          this.showToast("Region Selected", `Viewing ${preset.name}`, "info");
        }
      });
    });
  }

  bindModals() {
    // Source & Limitations Modal
    const sourcesBtn = document.getElementById('sourcesInfoBtn');
    const sourcesModal = document.getElementById('sourcesModal');
    const closeSourcesBtn = document.getElementById('closeSourcesModal');

    if (sourcesBtn && sourcesModal) {
      sourcesBtn.addEventListener('click', () => sourcesModal.classList.remove('hidden'));
    }
    if (closeSourcesBtn && sourcesModal) {
      closeSourcesBtn.addEventListener('click', () => sourcesModal.classList.add('hidden'));
    }

    // Case Studies Modal
    const caseStudiesBtn = document.getElementById('caseStudiesBtn');
    const caseStudiesModal = document.getElementById('caseStudiesModal');
    const closeCaseStudiesBtn = document.getElementById('closeCaseStudiesModal');

    if (caseStudiesBtn && caseStudiesModal) {
      caseStudiesBtn.addEventListener('click', () => caseStudiesModal.classList.remove('hidden'));
    }
    if (closeCaseStudiesBtn && caseStudiesModal) {
      closeCaseStudiesBtn.addEventListener('click', () => caseStudiesModal.classList.add('hidden'));
    }

    // Close on backdrop click
    [sourcesModal, caseStudiesModal].forEach(modal => {
      if (modal) {
        modal.addEventListener('click', (e) => {
          if (e.target === modal) modal.classList.add('hidden');
        });
      }
    });
  }

  renderSourceInfo() {
    const listEl = document.getElementById('limitationsList');
    if (!listEl) return;

    listEl.innerHTML = SCIENTIFIC_LIMITATIONS.limitations.map(lim => `
      <div class="limitation-item">
        <h5 class="lim-title">⚠️ ${lim.title}</h5>
        <p class="lim-desc">${lim.description}</p>
      </div>
    `).join('');
  }

  bindKeyboardShortcuts() {
    window.addEventListener('keydown', (e) => {
      // Don't trigger if typing in an input
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;

      if (e.key === 'c' || e.key === 'C') {
        this.compare.toggleCompareMode(!this.compare.isActive);
      } else if (e.key === 't' || e.key === 'T') {
        const trendModal = document.getElementById('trendAnalysisModal');
        if (trendModal) {
          trendModal.classList.toggle('hidden');
          if (!trendModal.classList.contains('hidden') && this.trendUI) {
            this.trendUI.runAndDisplayAnalysis();
          }
        }
      } else if (e.key === 'r' || e.key === 'R') {
        this.map.resetToBangladesh();
      } else if (e.key === ' ') {
        if (this.compare.isActive) {
          e.preventDefault();
          this.compare.animateCurtain();
        }
      }
    });
  }

  showToast(title, message, type = "info") {
    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast-item toast-${type}`;
    toast.innerHTML = `
      <div class="toast-header">
        <span class="toast-badge">${type === 'warning' ? '⚠️ NOTICE' : 'ℹ️ UPDATE'}</span>
        <strong class="toast-title">${title}</strong>
      </div>
      <div class="toast-body">${message}</div>
    `;

    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 400);
    }, 4500);
  }

  captureSnapshot() {
    this.showToast("Snapshot Ready", "Generating NASA observation report card...", "info");
    const activeLayer = NASA_LAYERS[this.currentLayerId];
    
    // Print window or trigger clean print report
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>EarthGuard AI Observation Brief - ${this.currentDate}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b1120; color: #f1f5f9; padding: 40px; margin: 0; }
            .header { border-bottom: 2px solid #38bdf8; padding-bottom: 20px; margin-bottom: 25px; }
            h1 { color: #38bdf8; margin: 0 0 10px 0; font-size: 26px; }
            .meta-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; background: #1e293b; padding: 20px; border-radius: 8px; margin-bottom: 25px; }
            .fact-badge { background: #0369a1; color: #fff; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
            .ethics { border-left: 4px solid #f59e0b; padding-left: 15px; margin-top: 30px; font-size: 13px; color: #94a3b8; }
          </style>
        </head>
        <body>
          <div class="header">
            <span class="fact-badge">NASA SPACE APPS CHALLENGE</span>
            <h1>EarthGuard AI - Earth Observation Record</h1>
            <p>Region: Bangladesh & Bay of Bengal Delta | Timestamp: ${this.currentDate}</p>
          </div>
          <div class="meta-grid">
            <div><strong>Active Sensor:</strong> ${activeLayer.name}</div>
            <div><strong>Satellite Platform:</strong> ${activeLayer.satellite}</div>
            <div><strong>Ground Spatial Resolution:</strong> ${activeLayer.resolution}</div>
            <div><strong>Data Service:</strong> NASA GIBS WMTS Web Mercator</div>
          </div>
          <p><strong>Science Overview:</strong> ${activeLayer.description}</p>
          <div class="ethics">
            <strong>Scientific Ethics & Disclaimer:</strong> EarthGuard AI displays real public NASA Earth observations. It strictly does not forecast future natural disasters, simulate casualty figures, or fabricate sensor measurements. For real-time warnings, refer to BMD (bmd.gov.bd) and FFWC (ffwc.gov.bd).
          </div>
          <script>
            window.onload = () => { setTimeout(() => window.print(), 500); };
          </script>
        </body>
        </html>
      `);
      printWindow.document.close();
    }
  }

  handleAssistantAction(action, payload) {
    if (action === 'FLY_TO') {
      this.map.flyToRegion(payload.regionId);
    }
  }
}

// Launch on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.earthGuardApp = new EarthGuardApp();
});
