@echo off
title EarthGuard AI - NASA Space Apps Challenge
echo Starting EarthGuard AI Local Server...
powershell -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
pause
