/**
 * EarthGuard AI - Interactive Decadal Trend UI & Chart Visualizer
 * NASA Space Apps Challenge Project
 */

import { NASA_DECADAL_DATASETS, analyzeEnvironmentalTrend } from './stats.js';

export class EarthGuardTrendUI {
  constructor(aiAssistantInstance) {
    this.ai = aiAssistantInstance;
    this.currentDatasetKey = "sundarbans_ndvi";
    this.modalEl = document.getElementById('trendAnalysisModal');

    this.initUI();
  }

  initUI() {
    this.bindEvents();
    this.renderDatasetSelector();
    this.runAndDisplayAnalysis();
  }

  bindEvents() {
    // Open Trend Modal button in header
    const openBtn = document.getElementById('openTrendModalBtn');
    if (openBtn) {
      openBtn.addEventListener('click', () => {
        if (this.modalEl) {
          this.modalEl.classList.remove('hidden');
          this.runAndDisplayAnalysis();
        }
      });
    }

    // Close button
    const closeBtn = document.getElementById('closeTrendModalBtn');
    if (closeBtn && this.modalEl) {
      closeBtn.addEventListener('click', () => {
        this.modalEl.classList.add('hidden');
      });
    }

    // Backdrop click
    if (this.modalEl) {
      this.modalEl.addEventListener('click', (e) => {
        if (e.target === this.modalEl) {
          this.modalEl.classList.add('hidden');
        }
      });
    }

    // Dataset select change
    const datasetSelect = document.getElementById('trendDatasetSelect');
    if (datasetSelect) {
      datasetSelect.addEventListener('change', (e) => {
        this.currentDatasetKey = e.target.value;
        this.runAndDisplayAnalysis();
      });
    }

    // Send to AI Assistant Chat button
    const askAiBtn = document.getElementById('trendAskAiBtn');
    if (askAiBtn) {
      askAiBtn.addEventListener('click', () => {
        this.pipeToAssistant();
      });
    }
  }

  renderDatasetSelector() {
    const select = document.getElementById('trendDatasetSelect');
    if (!select) return;

    select.innerHTML = Object.values(NASA_DECADAL_DATASETS).map(ds => `
      <option value="${ds.id}" ${ds.id === this.currentDatasetKey ? 'selected' : ''}>
        ${ds.title} (${ds.timeframe})
      </option>
    `).join('');
  }

  runAndDisplayAnalysis() {
    const results = analyzeEnvironmentalTrend(this.currentDatasetKey);
    const { dataset, mk, ts, plainLanguageExplanation } = results;

    this.currentResults = results;

    // 1. Render Interactive Chart
    this.renderChart(dataset, ts);

    // 2. Render Attached Statistical Proof Table
    this.renderStatisticsTable(dataset, mk, ts);

    // 3. Render Plain Language Explanation
    this.renderPlainLanguageExplanation(dataset, mk, ts, plainLanguageExplanation);
  }

  /**
   * Generates clean, crisp responsive SVG time-series chart with Theil-Sen line
   */
  renderChart(dataset, ts) {
    const container = document.getElementById('trendChartContainer');
    if (!container) return;

    const width = 740;
    const height = 300;
    const padding = { top: 30, right: 35, bottom: 45, left: 65 };

    const years = dataset.years;
    const values = dataset.values;

    const minX = years[0];
    const maxX = years[years.length - 1];

    const rawMinY = Math.min(...values);
    const rawMaxY = Math.max(...values);
    const yMargin = (rawMaxY - rawMinY) * 0.15 || 0.1;
    const minY = rawMinY - yMargin;
    const maxY = rawMaxY + yMargin;

    const getX = (year) => padding.left + ((year - minX) / (maxX - minX)) * (width - padding.left - padding.right);
    const getY = (val) => height - padding.bottom - ((val - minY) / (maxY - minY)) * (height - padding.top - padding.bottom);

    // Build data line points
    const points = years.map((y, i) => `${getX(y)},${getY(values[i])}`).join(' ');

    // Theil-Sen trend line points (from first year to last year)
    const tsX1 = getX(ts.firstYear);
    const tsY1 = getY(ts.startY);
    const tsX2 = getX(ts.lastYear);
    const tsY2 = getY(ts.endY);

    // Grid lines for Y axis (4 steps)
    const ySteps = 4;
    let yGridHtml = "";
    for (let step = 0; step <= ySteps; step++) {
      const val = minY + (step / ySteps) * (maxY - minY);
      const yCoord = getY(val);
      yGridHtml += `
        <line x1="${padding.left}" y1="${yCoord}" x2="${width - padding.right}" y2="${yCoord}" stroke="rgba(255,255,255,0.08)" stroke-dasharray="3,3" />
        <text x="${padding.left - 8}" y="${yCoord + 4}" fill="#94a3b8" font-size="10" text-anchor="end" font-family="monospace">
          ${val.toFixed(dataset.unit.includes("°C") ? 1 : (dataset.unit.includes("sq km") ? 0 : 3))}
        </text>
      `;
    }

    // Grid lines for X axis (every 4 years)
    let xGridHtml = "";
    for (let year = minX; year <= maxX; year += 4) {
      const xCoord = getX(year);
      xGridHtml += `
        <line x1="${xCoord}" y1="${height - padding.bottom}" x2="${xCoord}" y2="${padding.top}" stroke="rgba(255,255,255,0.06)" />
        <text x="${xCoord}" y="${height - padding.bottom + 18}" fill="#94a3b8" font-size="11" text-anchor="middle" font-family="monospace">
          ${year}
        </text>
      `;
    }
    // Ensure final year (2024) is labeled
    if ((maxX - minX) % 4 !== 0) {
      const finalX = getX(maxX);
      xGridHtml += `
        <text x="${finalX}" y="${height - padding.bottom + 18}" fill="#38bdf8" font-size="11" text-anchor="middle" font-family="monospace" font-weight="bold">
          ${maxX}
        </text>
      `;
    }

    // Render interactive data dots
    const dotsHtml = years.map((year, i) => {
      const cx = getX(year);
      const cy = getY(values[i]);
      return `
        <g class="chart-dot-group" data-year="${year}" data-val="${values[i]}">
          <circle cx="${cx}" cy="${cy}" r="4.5" fill="#38bdf8" stroke="#0b1120" stroke-width="1.5" />
          <title>${year}: ${values[i]} ${dataset.unit}</title>
        </g>
      `;
    }).join('');

    const slopeLabelSign = ts.slope >= 0 ? '+' : '';
    const slopeFormatted = `${slopeLabelSign}${ts.slope.toFixed(4)} ${dataset.unit}/yr`;

    container.innerHTML = `
      <div class="chart-header-row">
        <div>
          <span class="chart-sensor-badge">🛰️ ${dataset.sensor}</span>
          <h4 class="chart-title">${dataset.title}</h4>
          <span class="chart-subtitle">${dataset.region} (${dataset.timeframe})</span>
        </div>
        <div class="chart-legend-box">
          <div class="legend-item"><span class="legend-dot-data"></span> NASA Observed Points</div>
          <div class="legend-item"><span class="legend-line-ts"></span> Theil-Sen Robust Slope (${slopeFormatted})</div>
        </div>
      </div>

      <div class="svg-chart-wrapper">
        <svg viewBox="0 0 ${width} ${height}" class="trend-svg" preserveAspectRatio="xMidYMid meet">
          <!-- Background grids -->
          ${yGridHtml}
          ${xGridHtml}

          <!-- Observed data line -->
          <polyline points="${points}" fill="none" stroke="rgba(56, 189, 248, 0.45)" stroke-width="1.8" />

          <!-- Theil-Sen Robust Trendline -->
          <line x1="${tsX1}" y1="${tsY1}" x2="${tsX2}" y2="${tsY2}" stroke="#f59e0b" stroke-width="2.5" stroke-linecap="round" />

          <!-- Data Points -->
          ${dotsHtml}
        </svg>
      </div>

      <div class="chart-footnote">
        <span>💡 Hover dots to inspect year-by-year values. Yellow line shows Theil-Sen median slope robust against cyclone and flood outliers.</span>
      </div>
    `;
  }

  /**
   * Renders the Attached Statistical Proof Table
   */
  renderStatisticsTable(dataset, mk, ts) {
    const container = document.getElementById('trendStatsTableContainer');
    if (!container) return;

    const slopeSign = ts.slope >= 0 ? '+' : '';
    const pValFormatted = mk.pValue < 0.0001 ? '< 0.0001' : mk.pValue.toFixed(4);

    let badgeClass = "badge-stable";
    let badgeLabel = "No Trend (Stable Baseline)";
    if (mk.isSignificant05) {
      if (mk.S > 0) {
        badgeClass = "badge-increase";
        badgeLabel = "Significant Upward Trend (p < 0.05)";
      } else {
        badgeClass = "badge-decrease";
        badgeLabel = "Significant Downward Trend (p < 0.05)";
      }
    }

    container.innerHTML = `
      <div class="stats-proof-card">
        <div class="proof-header">
          <div class="proof-title-group">
            <span class="proof-badge-icon">📊</span>
            <div>
              <h5 class="proof-title">ATTACHED STATISTICAL PROOF & MATHEMATICAL RIGOR</h5>
              <span class="proof-subtitle">Non-parametric rank correlation & median pairwise slopes over 25 years</span>
            </div>
          </div>
          <span class="trend-conclusion-badge ${badgeClass}">${badgeLabel}</span>
        </div>

        <div class="stats-metrics-grid">
          <div class="metric-box">
            <span class="metric-label">Sample Size (n)</span>
            <strong class="metric-val">${mk.n} Years</strong>
            <span class="metric-sub">2000 to 2024</span>
          </div>

          <div class="metric-box">
            <span class="metric-label">Kendall's Score (S)</span>
            <strong class="metric-val">${mk.S > 0 ? '+' : ''}${mk.S}</strong>
            <span class="metric-sub">Directional concordances</span>
          </div>

          <div class="metric-box">
            <span class="metric-label">Var(S) & Std Dev</span>
            <strong class="metric-val">${mk.varS.toFixed(1)}</strong>
            <span class="metric-sub">σ = ${mk.stdDevS.toFixed(2)} (ties adjusted)</span>
          </div>

          <div class="metric-box">
            <span class="metric-label">Z-Test Statistic</span>
            <strong class="metric-val">${mk.Z.toFixed(3)}</strong>
            <span class="metric-sub">${Math.abs(mk.Z) > 1.96 ? '|Z| > 1.96 (Critical)' : '|Z| ≤ 1.96'}</span>
          </div>

          <div class="metric-box highlight">
            <span class="metric-label">Two-Tailed p-value</span>
            <strong class="metric-val ${mk.isSignificant05 ? 'val-sig' : 'val-nonsig'}">${pValFormatted}</strong>
            <span class="metric-sub">${mk.isSignificant05 ? 'Reject Null H₀ (α = 0.05)' : 'Accept Null H₀'}</span>
          </div>

          <div class="metric-box">
            <span class="metric-label">Kendall's Tau (τ)</span>
            <strong class="metric-val">${mk.tau.toFixed(4)}</strong>
            <span class="metric-sub">Rank correlation</span>
          </div>

          <div class="metric-box highlight-amber">
            <span class="metric-label">Theil-Sen Slope (β)</span>
            <strong class="metric-val">${slopeSign}${ts.slope.toFixed(4)}</strong>
            <span class="metric-sub">${dataset.unit} / year</span>
          </div>

          <div class="metric-box">
            <span class="metric-label">Sen's Intercept (α)</span>
            <strong class="metric-val">${ts.intercept.toFixed(2)}</strong>
            <span class="metric-sub">Base model constant</span>
          </div>
        </div>

        <div class="proof-equation-row">
          <div class="eq-item">
            <span class="eq-label">Fitted Theil-Sen Equation:</span>
            <code class="eq-code">ŷ(t) = ${ts.intercept.toFixed(3)} ${slopeSign} ${ts.slope.toFixed(4)} × (Year)</code>
          </div>
          <div class="eq-item">
            <span class="eq-label">Total 25-Year Change:</span>
            <strong class="eq-val">${slopeSign}${ts.totalChangeOverPeriod.toFixed(3)} ${dataset.unit}</strong>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Renders the Plain-Language Explanation for Students & Local Communities
   */
  renderPlainLanguageExplanation(dataset, mk, ts, explanation) {
    const container = document.getElementById('trendPlainLanguageContainer');
    if (!container) return;

    container.innerHTML = `
      <div class="plain-language-card">
        <div class="pl-header">
          <span class="pl-icon">🤖</span>
          <div>
            <h5 class="pl-title">PLAIN-LANGUAGE SCIENTIFIC EXPLANATION</h5>
            <span class="pl-subtitle">Translating mathematical statistics for students, educators & community members</span>
          </div>
        </div>

        <div class="pl-body">
          <div class="pl-section">
            <h6 class="pl-section-title">1. What Does the 25-Year Data Show?</h6>
            <p>${explanation.summaryParagraph}</p>
          </div>

          <div class="pl-section community-callout">
            <h6 class="pl-section-title">2. What This Means for Local Communities & Ecology</h6>
            <p>${explanation.communityTakeaway}</p>
          </div>

          <div class="pl-section math-rationale">
            <h6 class="pl-section-title">3. Why Non-Parametric Statistics Matter</h6>
            <p>${explanation.whyMethodMatters}</p>
          </div>
        </div>

        <div class="pl-ethics-note">
          <span>⚠️ <strong>Scientific Ethics Reminder:</strong> This analysis evaluates historical NASA satellite telemetry from 2000 to 2024. It does not predict future disaster occurrences, simulate future casualties, or fabricate sensor readings. For official warnings, consult BMD and FFWC.</span>
        </div>
      </div>
    `;
  }

  /**
   * Pipes current statistical findings into the AI Assistant conversation
   */
  pipeToAssistant() {
    if (!this.currentResults || !this.ai) return;

    const { dataset, mk, ts, plainLanguageExplanation } = this.currentResults;
    const slopeSign = ts.slope >= 0 ? '+' : '';

    // Close modal
    if (this.modalEl) {
      this.modalEl.classList.add('hidden');
    }

    // Open mobile sidebar if on small screen
    const sidebarPanel = document.getElementById('sidebarPanel');
    if (sidebarPanel) {
      sidebarPanel.classList.add('open');
    }

    this.ai.appendMessage({
      sender: "user",
      text: `Explain the 25-year Mann-Kendall trend test and Theil-Sen slope results for ${dataset.title} (${dataset.timeframe}).`
    });

    setTimeout(() => {
      this.ai.appendMessage({
        sender: "assistant",
        verifiedData: {
          testMethod: "Mann-Kendall Trend Test & Theil-Sen Robust Estimator",
          dataset: `${dataset.sensor} (${dataset.timeframe})`,
          sampleSize: `${mk.n} consecutive annual observations`,
          senSlope: `${slopeSign}${ts.slope.toFixed(4)} ${dataset.unit}/year`,
          kendallScore: `S = ${mk.S}, Var(S) = ${mk.varS.toFixed(1)}, Z = ${mk.Z.toFixed(3)}`,
          statisticalSignificance: `p = ${mk.pValue.toFixed(4)} (${mk.isSignificant05 ? 'p < 0.05: Statistically Significant' : 'p ≥ 0.05: Not Significant'})`,
          total25YearShift: `${slopeSign}${ts.totalChangeOverPeriod.toFixed(3)} ${dataset.unit}`
        },
        explanation: `Here is the scientific breakdown of **${dataset.title}** across two decades of NASA observations:

### 📈 Plain-Language Translation
${plainLanguageExplanation.summaryParagraph}

### 🌿 Community & Ecological Takeaway
${plainLanguageExplanation.communityTakeaway}

### 🔬 Why this statistical test is trustworthy:
${plainLanguageExplanation.whyMethodMatters}

Feel free to ask me questions like:
- *"Why did the Sundarbans greenness drop in 2008 and 2020?"*
- *"How does Theil-Sen handle extreme monsoon flood years?"*
- *"Can we use this data to study climate adaptation in Bangladesh?"*`
      });
    }, 450);
  }
}
