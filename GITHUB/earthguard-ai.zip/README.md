# 🛰️ EarthGuard AI

[![NASA Space Apps](https://img.shields.io/badge/NASA%20Space%20Apps-Challenge-0284c7?style=for-the-badge&logo=nasa)](https://www.spaceappschallenge.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-emerald?style=for-the-badge)](LICENSE)
[![Data: NASA GIBS](https://img.shields.io/badge/Data-NASA%20GIBS%20EOSDIS-0ea5e9?style=for-the-badge)](https://earthdata.nasa.gov/eosdis/science-system-description/eosdis-components/gibs)
[![Statistics: Mann-Kendall](https://img.shields.io/badge/Stats-Mann--Kendall%20%26%20Theil--Sen-amber?style=for-the-badge)](https://en.wikipedia.org/wiki/Kendall_rank_correlation_coefficient)
[![GitHub Pages](https://img.shields.io/badge/Deploy-GitHub%20Pages%20Ready-success?style=for-the-badge&logo=github)](https://pages.github.com/)

**A NASA Space Apps Challenge Project**  
*Empowering Students, Local Communities, and Earth Science Enthusiasts with Transparent Earth Observation Data & AI-Powered Environmental Explanations.*

---

## 🌍 Executive Summary

**EarthGuard AI** is a responsive, web-based Earth observation platform designed to demystify complex satellite remote sensing data for students, environmental educators, and local communities. Centered on the dynamic delta landscape of **Bangladesh and the Bay of Bengal**, the application streams authentic NASA Earth observations directly from **NASA's Global Imagery Browse Services (GIBS)** and pairs them with an AI Science Explainer that translates radiometric bands, seasonal floods, sediment dynamics, and atmospheric phenomena into plain, engaging language.

### 🎯 Target Audience
- **High school & university students:** Visualizing hydrology, geography, and climate concepts in real world context.
- **Local communities & environmental volunteers:** Observing macro flood runoff, haor wetland seasonal cycles, and mangrove coastlines.
- **Earth science educators:** Utilizing interactive split-screen before-and-after studies for interactive classroom learning.

---

## 🌟 Key Features

### 1. Authentic NASA GIBS Satellite Imagery
Connects directly to NASA EOSDIS GIBS via standardized Web Mercator (EPSG:3857) WMTS tile services:
- **MODIS Terra (True Color):** Natural color morning overpass (~10:30 AM local time), capturing regional smoke, cloud fronts, and sediment plumes.
- **VIIRS Suomi-NPP (True Color 375m):** High-clarity 375-meter resolution imagery bands providing sharper riverbank and coastline detail.
- **MODIS Aqua (True Color):** Afternoon pass (~1:30 PM local time); enables comparison with Terra to observe rapid diurnal cloud and runoff progression.
- **MODIS Terra (False Color Bands 7-2-1):** Combines Shortwave Infrared (Band 7), Near-Infrared (Band 2), and Red (Band 1). Standing water absorbs infrared and appears **deep black or navy blue**, while healthy vegetation reflects near-infrared and appears **radiant electric green**. Crucial for flood inundation mapping in Bangladesh.
- **VIIRS Day/Night Band (Night Lights):** Highly sensitive nocturnal sensor recording urban power footprints and offshore night-fishing fleets in the Bay of Bengal.

### 2. Real Mann-Kendall Trend Test & Theil-Sen Robust Slope (2000–2024 Record)
Executes mathematically rigorous, non-parametric statistical tests directly in the browser over **two full decades (25 consecutive years)** of NASA MODIS/EOSDIS observations across Bangladesh:
- **Mann-Kendall Trend Test:** Evaluates directional concordance across all observation pairs ($N = 300$), applying tied-group variance corrections $\operatorname{Var}(S)$ to compute the standardized $Z$-score, two-tailed $p$-value, and Kendall's $\tau$. Determines whether environmental changes are statistically genuine ($p < 0.05$) or natural random noise.
- **Theil-Sen Median Slope Estimator:** Computes the median of all 300 pairwise slopes $d_{ij} = (y_j - y_i) / (t_j - t_i)$. Completely resilient against severe weather outliers (e.g. Cyclone Sidr in 2007 or the record 2022 Sylhet flash flood) that would bias standard linear regression.
- **5 Multi-Decadal Datasets Analyzed:**
  1. *Sundarbans Mangrove Greenness (MODIS MOD13A2 NDVI)*: Tracks post-cyclone defoliation and biological resilience.
  2. *Central Bangladesh Land Surface Temperature (MOD11A2 Daytime LST)*: Documents daytime thermal increases (+0.082°C/yr, $p < 0.001$).
  3. *Sylhet Haor Peak Monsoon Inundation (MOD44W / False Color)*: Demonstrates cyclical hydrological variability ($p > 0.05$).
  4. *Atmospheric Aerosol Optical Depth (MCD19A2 AOD at 550nm)*: Documents decadal winter haze and particulate changes (+42% increase).
  5. *Barind Tract Agricultural Greening (MOD13A2 Boro NDVI)*: Highlights regional food production transformation through tubewell irrigation.
- **Attached Statistical Proof & Plain-Language Translation:** Presents an interactive SVG time-series chart with Theil-Sen trendline, exact numerical parameters ($n, S, \operatorname{Var}(S), Z, p, \tau, \beta, \alpha$), followed by an educational plain-language breakdown of what the numbers mean for local communities.

### 3. Interactive Compare-Dates Feature (Split-Screen Curtain)
- Smooth 60fps draggable curtain divider allowing side-by-side or before-and-after comparison.
- Contrast pre-monsoon dry season against peak monsoon inundation (e.g. March vs. July in Sylhet).
- Cross-spectral comparison: examine true color visible light alongside false-color infrared on the exact same date.
- Quick "Swap Dates" and animated sweep features.

### 3. AI Science Explainer (EarthGuard Assistant)
- Translates spectral observations and Earth science concepts into accessible, engaging summaries.
- Pre-configured interactive prompts for rapid inquiry:
  - *How does False Color detect floods?*
  - *Why do clouds block satellite views during monsoons?*
  - *What are the swirling brown patterns in the Bay of Bengal?*
  - *How do the Sundarbans protect coastal towns from storm surges?*
- Context-aware briefing automatically updates whenever the user changes dates, layers, or regions.

### 4. Transparent Distinction: Satellite Data vs. AI Interpretation
Every observation card and conversational answer strictly separates:
- 🛰️ **NASA SATELLITE OBSERVATION [VERIFIED DATA FACT]:** Confirmed sensor telemetry, satellite platform, ground pixel resolution, and radiometric band specifications.
- 🤖 **AI EDUCATIONAL EXPLANATION [SYNTHESIS FOR LEARNERS]:** Plain-language synthesis explaining physical processes for conceptual understanding.

### 5. Strict Scientific Ethics & Integrity
- **No Fabricated Measurements:** The system never invents numerical sensor readings.
- **No Disaster Prediction Claims:** EarthGuard AI explains historical and observational data. It explicitly disclaims disaster forecasting or casualty projections and directs users to official government warning centers:
  - **Bangladesh Meteorological Department (BMD):** [live.bmd.gov.bd](https://live.bmd.gov.bd)
  - **Flood Forecasting and Warning Centre (FFWC):** [ffwc.gov.bd](https://ffwc.gov.bd)

### 6. Full Disclosure of Physical Limitations
- **Cloud Cover Obstruction:** Explains why passive optical sensors cannot penetrate monsoon rain clouds and introduces microwave radar (SAR) principles.
- **Spatial Resolution Scale:** Clarifies why 250m–750m resolution is optimal for regional delta monitoring but cannot resolve individual vehicles or buildings.
- **Temporal Revisit Interval:** Details 1–2 daily satellite passes vs. streaming cameras.
- **Data Ingestion Latency:** Notes the standard 3–5 hour window required for orbital downlink and calibration.

### 7. Modern Dark-Blue Space Theme & Accessibility
- Mission-control dark navy palette (`#060913`, `#0a0f1d`, starlight cyan `#38bdf8`, aurora green `#10b981`).
- Real-time HUD status indicator with pulsating telemetry dot and progress spinner.
- Real-time Latitude, Longitude, and Zoom level readout.
- Fully responsive layout with mobile drawer and quick regional jump bookmarks.
- Printable/exportable Observation Brief for student homework and research documentation.

---

## 📁 Project Architecture

```
earthguard-ai/
│
├── index.html              # Main responsive application markup
├── serve.ps1               # Lightweight local HTTP server (uses built-in .NET HttpListener)
├── start-app.bat           # One-click Windows launcher
├── README.md               # Project documentation & science references
│
├── css/
│   └── styles.css          # Space-themed design system, HUD overlays, split slider & responsive styles
│
├── js/
│   ├── config.js           # NASA GIBS layer definitions, presets, science limits & regional bounds
│   ├── stats.js            # Mann-Kendall test, Theil-Sen slope & 25-yr NASA datasets
│   ├── trend-ui.js         # Interactive SVG time-series chart, statistical proof & plain language UI
│   ├── map.js              # Leaflet engine, GIBS WMTS tiles, split-view clipping & error handling
│   ├── ai-assistant.js     # AI Science Explainer engine, telemetry vs AI badges & query processor
│   ├── compare.js          # Dual date comparison controller, case studies loader & swipe animator
│   └── app.js              # Application coordinator, keyboard shortcuts & toast notifications
│
└── assets/                 # Icons and supplementary static media
```

---

## 🚀 How to Run the Prototype

No Node.js, Python, or complex build tools are required! EarthGuard AI runs natively in any modern web browser.

### Option 1: One-Click Windows Launcher (Recommended)
1. Double-click `start-app.bat` inside the `earthguard-ai` folder.
2. This launches the built-in PowerShell web server (`http://localhost:8080/`) and automatically opens your default web browser.

### Option 2: PowerShell Command Line
Open PowerShell in the project directory and run:
```powershell
powershell -ExecutionPolicy Bypass -File .\serve.ps1
```
Then visit `http://localhost:8080/` in your browser.

### Option 3: Direct File Opening
Double-click `index.html` to open it directly in **Google Chrome**, **Microsoft Edge**, or **Firefox**.

---

## 🌐 Deploy to GitHub Pages (Live Free Web Hosting)

Because EarthGuard AI is a 100% client-side web application with zero server build steps, you can host it live on the web for free via **GitHub Pages**:

1. Create a repository on GitHub (e.g. `earthguard-ai`).
2. Push or upload these files to the repository's `main` branch.
3. In your GitHub repository, go to **Settings** ➔ **Pages** (under "Code and automation").
4. Under **Build and deployment** ➔ **Source**, select **Deploy from a branch**.
5. Set branch to **`main`** and folder to **`/ (root)`**, then click **Save**.
6. Within 1 minute, GitHub will give you a live HTTPS URL:
   `https://<YOUR-USERNAME>.github.io/earthguard-ai/`

---

## ⌨️ Keyboard Shortcuts

| Key | Action |
|---|---|
| `C` | Toggle Split Compare Mode on / off |
| `T` | Open 20-Year Decadal Trend Analyzer (Mann-Kendall & Theil-Sen) |
| `R` | Reset map focus to Bangladesh default view |
| `Space` | Animate the split comparison curtain sweep (when in Compare Mode) |

---

## 📚 Scientific References & Data Sources

1. **NASA Global Imagery Browse Services (GIBS):**  
   Part of the NASA Earth Science Data and Information System (ESDIS) Project.  
   Tile Service Endpoint: `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/`  
   [https://earthdata.nasa.gov/eosdis/science-system-description/eosdis-components/gibs](https://earthdata.nasa.gov/eosdis/science-system-description/eosdis-components/gibs)

2. **NASA EOSDIS Worldview:**  
   Interactive full-resolution Earth observation browser.  
   [https://worldview.earthdata.nasa.gov](https://worldview.earthdata.nasa.gov)

3. **MODIS (Moderate Resolution Imaging Spectroradiometer):**  
   NASA Goddard Space Flight Center.  
   [https://modis.gsfc.nasa.gov](https://modis.gsfc.nasa.gov)

4. **VIIRS (Visible Infrared Imaging Radiometer Suite):**  
   NASA & NOAA Joint Polar Satellite System (JPSS).  
   [https://www.star.nesdis.noaa.gov/jpss/viirs.php](https://www.star.nesdis.noaa.gov/jpss/viirs.php)

5. **Bangladesh Flood Forecasting and Warning Centre (FFWC):**  
   Authoritative water level and flood advisories.  
   [https://ffwc.gov.bd](https://ffwc.gov.bd)

6. **Bangladesh Meteorological Department (BMD):**  
   National meteorological forecasts and cyclonic storm warnings.  
   [https://live.bmd.gov.bd](https://live.bmd.gov.bd)

---

## ⚖️ License & Open Science Attribution
Developed for the **NASA Space Apps Challenge**. All NASA satellite imagery and GIBS services are in the public domain and provided courtesy of NASA EOSDIS.
